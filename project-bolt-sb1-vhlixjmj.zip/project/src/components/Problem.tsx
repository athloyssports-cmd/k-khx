import { AlertTriangle, Eye, Users, MapPin, BarChart2 } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const problems = [
  {
    icon: Eye,
    stat: '99%',
    title: 'Talent Never Identified',
    description: 'The "eye test" leaves 99% of student potential undiscovered. Subjective selection prioritizes today\'s physical size over tomorrow\'s physiological ceiling.',
    color: 'text-rose-500',
    bg: 'bg-rose-50',
    border: 'border-rose-100',
  },
  {
    icon: Users,
    stat: '30%',
    title: 'PE Teacher Shortage',
    description: 'One in three schools lacks a dedicated physical education teacher. Expert talent identification cannot scale without automation and standardized tools.',
    color: 'text-orange-500',
    bg: 'bg-orange-50',
    border: 'border-orange-100',
  },
  {
    icon: MapPin,
    stat: '23%',
    title: 'Playground Gap',
    description: 'Nearly a quarter of schools lack a playground. Talent discovery is tethered to elite infrastructure, hiding raw potential behind geographic barriers.',
    color: 'text-amber-500',
    bg: 'bg-amber-50',
    border: 'border-amber-100',
  },
  {
    icon: BarChart2,
    stat: '6%',
    title: 'Sports Participation',
    description: 'Only 6% of India\'s population regularly participates in sport. Fragmented stakeholder efforts and absent data systems prevent the ecosystem from connecting.',
    color: 'text-sky-500',
    bg: 'bg-sky-50',
    border: 'border-sky-100',
  },
];

export default function Problem() {
  const { ref, inView } = useInView();

  return (
    <section id="problem" className="py-28 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div
          ref={ref}
          className={`text-center mb-16 fade-up ${inView ? 'visible' : ''}`}
        >
          <div className="inline-flex items-center gap-2 bg-rose-50 border border-rose-100 rounded-full px-4 py-1.5 mb-6">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
            <span className="text-rose-600 text-sm font-semibold">The Hidden Potential Crisis</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 tracking-tight mb-5">
            Traditional Scouting is a<br />Strategic Failure
          </h2>
          <p className="text-lg text-slate-500 max-w-2xl mx-auto leading-relaxed">
            The current system relies on subjective observation, operates in silos, and ignores
            the physiological data that actually predicts athletic excellence.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {problems.map((item, i) => {
            const Icon = item.icon;
            return (
              <div
                key={item.title}
                className={`fade-up stagger-${i + 1} ${inView ? 'visible' : ''} card-hover group border ${item.border} rounded-2xl p-8`}
              >
                <div className="flex items-start gap-5">
                  <div className={`${item.bg} ${item.border} border rounded-xl p-3 shrink-0`}>
                    <Icon className={`w-5 h-5 ${item.color}`} />
                  </div>
                  <div>
                    <div className={`text-3xl font-bold ${item.color} mb-1`}>{item.stat}</div>
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">{item.title}</h3>
                    <p className="text-slate-500 text-sm leading-relaxed">{item.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className={`mt-12 fade-up stagger-5 ${inView ? 'visible' : ''} bg-slate-900 rounded-2xl p-8 md:p-10`}>
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="flex-1">
              <p className="text-slate-400 text-sm font-semibold uppercase tracking-widest mb-2">Our Pivot</p>
              <h3 className="text-2xl font-bold text-white mb-3">Infrastructure Decoupling</h3>
              <p className="text-slate-400 leading-relaxed">
                We remove the dependency on elite stadiums. Our plug-and-play mobile engine enables
                high-precision talent identification in any space — a classroom, a courtyard, a corridor.
                No wearables. No expensive hardware. Just science and a smartphone.
              </p>
            </div>
            <div className="flex-shrink-0 grid grid-cols-2 gap-3 text-center">
              <div className="bg-white/5 rounded-xl px-5 py-4">
                <div className="text-2xl font-bold text-emerald-400">20 min</div>
                <div className="text-xs text-slate-400 mt-1">Per session</div>
              </div>
              <div className="bg-white/5 rounded-xl px-5 py-4">
                <div className="text-2xl font-bold text-emerald-400">2×</div>
                <div className="text-xs text-slate-400 mt-1">Per month</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
