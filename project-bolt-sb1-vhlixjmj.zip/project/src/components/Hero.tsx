import { ArrowRight, Play, TrendingUp, Users, School } from 'lucide-react';

const stats = [
  { value: '1,000+', label: 'Students Assessed', icon: Users },
  { value: '30+', label: 'Schools Pipeline', icon: School },
  { value: '72.73%', label: 'Predictive Accuracy', icon: TrendingUp },
];

export default function Hero() {
  return (
    <section className="relative min-h-screen bg-[#0A0F1E] overflow-hidden flex items-center">
      <div className="absolute inset-0 bg-grid-dark" />
      <div className="absolute inset-0 bg-gradient-to-br from-sky-950/40 via-transparent to-emerald-950/30" />

      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8 pt-24 pb-20 w-full">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-sky-500/10 border border-sky-500/20 rounded-full px-4 py-1.5 mb-8">
            <span className="w-2 h-2 bg-sky-400 rounded-full animate-pulse" />
            <span className="text-sky-300 text-sm font-medium">India's First AI-Powered School Sports Intelligence Platform</span>
          </div>

          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-[1.08] tracking-tight mb-6">
            Turn Every School Into a{' '}
            <span className="gradient-text">Talent Discovery</span>{' '}
            Engine
          </h1>

          <p className="text-lg md:text-xl text-slate-400 leading-relaxed max-w-2xl mx-auto mb-10">
            AI-powered fitness assessment, athlete scoring, and scouting ecosystem.
            We replace gut-feeling with precision measurement — at the grassroots level.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <a
              href="#cta"
              className="group flex items-center gap-2 bg-sky-500 hover:bg-sky-400 text-white font-semibold px-7 py-3.5 rounded-xl transition-all duration-200 hover:shadow-lg hover:shadow-sky-500/25"
            >
              Book a Demo
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </a>
            <a
              href="#solution"
              className="group flex items-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-white font-semibold px-7 py-3.5 rounded-xl transition-all duration-200"
            >
              <Play className="w-4 h-4" />
              Explore the Platform
            </a>
          </div>

          <div className="grid grid-cols-3 gap-4 max-w-2xl mx-auto">
            {stats.map(({ value, label, icon: Icon }) => (
              <div
                key={label}
                className="bg-white/5 border border-white/10 rounded-2xl p-4 text-center hover:bg-white/8 transition-colors"
              >
                <Icon className="w-5 h-5 text-sky-400 mx-auto mb-2" />
                <div className="text-2xl font-bold text-white mb-0.5">{value}</div>
                <div className="text-xs text-slate-400 font-medium">{label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-20 relative">
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent" />
          <div className="pt-12 text-center">
            <p className="text-slate-500 text-sm font-medium mb-6 uppercase tracking-widest">Trusted by leading institutions</p>
            <div className="flex flex-wrap justify-center items-center gap-x-10 gap-y-4">
              {['St. Lawrence High School', 'Fr. Agnel Pilar', 'St. Andrew High School', 'Sharda Mandir', 'Mustifund Schools'].map((school) => (
                <span key={school} className="text-slate-400 text-sm font-medium hover:text-slate-300 transition-colors">
                  {school}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
