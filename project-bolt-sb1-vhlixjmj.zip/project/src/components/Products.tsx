import { School, Trophy, Building2, CheckCircle2 } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const products = [
  {
    icon: School,
    audience: 'For Schools',
    headline: 'Institutional Excellence',
    tagline: 'NEP 2020 Aligned',
    description: 'Deploy professional-grade sports assessment without specialist staff. Fits into existing PE hours with zero academic disruption.',
    features: [
      'Plug-and-play teacher app — no training needed',
      'AI-generated Holistic Progress Cards',
      'Longitudinal tracking over 3–5 years',
      'Parent wellness reports with 90%+ satisfaction',
      'National Talent Leaderboard access',
    ],
    cta: 'Join the Beta',
    bg: 'bg-slate-900',
    text: 'text-white',
    badge: 'bg-sky-500/20 text-sky-300 border-sky-500/30',
    checkColor: 'text-sky-400',
    ctaStyle: 'bg-sky-500 hover:bg-sky-400 text-white',
  },
  {
    icon: Trophy,
    audience: 'For Athletes',
    headline: 'Your Digital Passport',
    tagline: 'Ages 6–16',
    description: 'Verified profiles that translate raw athletic data into recognized, portable credentials visible to scouts nationwide.',
    features: [
      'Verified athlete profile with performance history',
      'PPS and APR scores updated every session',
      'National and district leaderboard rankings',
      'Sport-specific alignment recommendations',
      'Scholarship pathway tracking',
    ],
    cta: 'Build Your Profile',
    bg: 'bg-white',
    text: 'text-slate-900',
    badge: 'bg-emerald-50 text-emerald-700 border-emerald-100',
    checkColor: 'text-emerald-500',
    ctaStyle: 'bg-slate-900 hover:bg-slate-800 text-white',
  },
  {
    icon: Building2,
    audience: 'For Academies',
    headline: 'Scouting as a Service',
    tagline: 'Talent Watch',
    description: 'Eliminate fragmented recruitment. Access the top 1% of the national talent funnel, identified by biological fingerprints — not geography.',
    features: [
      'Talent Watch dashboard with advanced filters',
      'APR-based athlete ranking by sport',
      'Verified performance history across sessions',
      'Direct connection to identified athletes',
      'Recruitment ROI analytics',
    ],
    cta: 'Request a Demo',
    bg: 'bg-sky-600',
    text: 'text-white',
    badge: 'bg-white/15 text-white border-white/20',
    checkColor: 'text-white/80',
    ctaStyle: 'bg-white text-sky-600 hover:bg-sky-50',
  },
];

export default function Products() {
  const { ref, inView } = useInView();

  return (
    <section id="products" className="py-28 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div
          ref={ref}
          className={`text-center mb-16 fade-up ${inView ? 'visible' : ''}`}
        >
          <div className="inline-flex items-center gap-2 bg-slate-100 rounded-full px-4 py-1.5 mb-6">
            <span className="text-slate-600 text-sm font-semibold">The Unified Five-Stage Highway</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 tracking-tight mb-5">
            Built for Every<br />Stakeholder
          </h2>
          <p className="text-lg text-slate-500 max-w-xl mx-auto leading-relaxed">
            Schools, athletes, and academies each get purpose-built tools that connect into one seamless intelligence network.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {products.map((product, i) => {
            const Icon = product.icon;
            return (
              <div
                key={product.audience}
                className={`fade-up stagger-${i + 1} ${inView ? 'visible' : ''} card-hover ${product.bg} rounded-2xl p-8 flex flex-col`}
              >
                <div>
                  <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full border ${product.badge} mb-6`}>
                    {product.tagline}
                  </span>
                  <div className="flex items-center gap-3 mb-4">
                    <Icon className={`w-6 h-6 ${product.text}`} />
                    <span className={`text-xs font-semibold uppercase tracking-widest ${product.text} opacity-60`}>
                      {product.audience}
                    </span>
                  </div>
                  <h3 className={`text-2xl font-bold ${product.text} mb-3`}>{product.headline}</h3>
                  <p className={`text-sm leading-relaxed mb-6 ${product.text} opacity-70`}>{product.description}</p>

                  <ul className="space-y-2.5 mb-8">
                    {product.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2.5">
                        <CheckCircle2 className={`w-4 h-4 mt-0.5 shrink-0 ${product.checkColor}`} />
                        <span className={`text-sm ${product.text} opacity-80`}>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-auto">
                  <a
                    href="#cta"
                    className={`block w-full text-center text-sm font-semibold px-5 py-3 rounded-xl transition-colors ${product.ctaStyle}`}
                  >
                    {product.cta}
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
