import { FlaskConical, Zap } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const ppsWeights = [
  { label: 'Physical Performance', value: 45, color: 'bg-sky-500' },
  { label: 'Anthropometrics', value: 25, color: 'bg-sky-400' },
  { label: 'Improvement Rate', value: 20, color: 'bg-cyan-400' },
  { label: 'Sport Alignment', value: 10, color: 'bg-cyan-300' },
];

const aprWeights = [
  { label: 'Flexibility', value: 30, color: 'bg-emerald-500' },
  { label: 'Strength', value: 25, color: 'bg-emerald-400' },
  { label: 'Speed & Agility', value: 20, color: 'bg-teal-400' },
  { label: 'Body Composition', value: 20, color: 'bg-teal-300' },
  { label: 'Balance', value: 15, color: 'bg-cyan-300' },
];

function WeightBar({ label, value, color }: { label: string; value: number; color: string }) {
  const { ref, inView } = useInView(0.2);
  return (
    <div ref={ref} className="space-y-1.5">
      <div className="flex items-center justify-between">
        <span className="text-sm text-slate-600 font-medium">{label}</span>
        <span className="text-sm font-bold text-slate-900">{value}%</span>
      </div>
      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
        <div
          className={`h-full ${color} rounded-full transition-all duration-1000 ease-out`}
          style={{ width: inView ? `${value}%` : '0%' }}
        />
      </div>
    </div>
  );
}

export default function Technology() {
  const { ref, inView } = useInView();

  return (
    <section id="technology" className="py-28 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div
          ref={ref}
          className={`text-center mb-16 fade-up ${inView ? 'visible' : ''}`}
        >
          <div className="inline-flex items-center gap-2 bg-sky-50 border border-sky-100 rounded-full px-4 py-1.5 mb-6">
            <FlaskConical className="w-3.5 h-3.5 text-sky-500" />
            <span className="text-sky-600 text-sm font-semibold">Deciphering the Biological Ceiling</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 tracking-tight mb-5">
            The Science Behind<br />Every Score
          </h2>
          <p className="text-lg text-slate-500 max-w-2xl mx-auto leading-relaxed">
            Our competitive moat is built on Kinesiology and exercise physiology. Multi-Layer Perceptron
            (MLP) models distinguish between trainable skills and non-negotiable biological constants.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          {[
            { value: '72.73%', label: 'Predictive Accuracy', sub: 'Talent forecasting precision' },
            { value: '0.665', label: 'R-Squared Value', sub: 'Model correlation strength' },
            { value: '1–15', label: 'Importance Scale', sub: 'Sport-specific weighting' },
          ].map((stat) => (
            <div key={stat.label} className={`fade-up ${inView ? 'visible' : ''} bg-slate-900 rounded-2xl p-6 text-center`}>
              <div className="text-4xl font-bold text-white mb-1">{stat.value}</div>
              <div className="text-sky-400 font-semibold text-sm mb-0.5">{stat.label}</div>
              <div className="text-slate-500 text-xs">{stat.sub}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className={`fade-up stagger-1 ${inView ? 'visible' : ''} bg-slate-50 border border-slate-100 rounded-2xl p-8`}>
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-sky-100 w-10 h-10 rounded-xl flex items-center justify-center">
                <FlaskConical className="w-5 h-5 text-sky-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900">PPS</h3>
                <p className="text-slate-400 text-xs">Physical Profile Score</p>
              </div>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed mb-6">
              A holistic wellness indicator measuring current physical standing and overall development.
              Used for parental wellness reports and NEP-compliant school-level health tracking.
            </p>
            <div className="space-y-4">
              {ppsWeights.map((w) => (
                <WeightBar key={w.label} {...w} />
              ))}
            </div>
            <div className="mt-6 pt-5 border-t border-slate-200">
              <p className="text-xs text-slate-400">
                <strong className="text-slate-600">Core metrics:</strong> Height, BMI, Flexibility, Balance
              </p>
            </div>
          </div>

          <div className={`fade-up stagger-2 ${inView ? 'visible' : ''} bg-slate-50 border border-slate-100 rounded-2xl p-8`}>
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-emerald-100 w-10 h-10 rounded-xl flex items-center justify-center">
                <Zap className="w-5 h-5 text-emerald-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900">APR</h3>
                <p className="text-slate-400 text-xs">Athlete Potential Rating</p>
              </div>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed mb-6">
              A high-performance forecasting metric for elite talent. Predicts future excellence and
              sport-specific alignment. Used for professional scouting and risk-mitigation in talent spend.
            </p>
            <div className="space-y-4">
              {aprWeights.map((w) => (
                <WeightBar key={w.label} {...w} />
              ))}
            </div>
            <div className="mt-6 pt-5 border-t border-slate-200">
              <p className="text-xs text-slate-400">
                <strong className="text-slate-600">Core metrics:</strong> Explosive Power, Speed, Agility, Limb Ratios
              </p>
            </div>
          </div>
        </div>

        <div className={`mt-8 fade-up stagger-3 ${inView ? 'visible' : ''} bg-sky-50 border border-sky-100 rounded-2xl p-6`}>
          <p className="text-slate-600 text-sm leading-relaxed text-center max-w-3xl mx-auto">
            <strong className="text-slate-900">The 1–15 Importance Scale:</strong> Height/Arm Span scores a "15" for Basketball but a "1" for Chess.
            This allows scouts to stop wasting resources on athletes who have already reached their biological ceiling in a specific discipline.
          </p>
        </div>
      </div>
    </section>
  );
}
