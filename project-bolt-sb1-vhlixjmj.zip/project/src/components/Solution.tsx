import { Brain, LayoutDashboard, BadgeCheck, Telescope } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const solutions = [
  {
    icon: Brain,
    title: 'AI-Driven PPS & APR Scoring',
    description: 'Proprietary algorithms normalize physical and skill data across age and gender, identifying biological advantages before they are visible to the naked eye.',
    accent: 'sky',
  },
  {
    icon: LayoutDashboard,
    title: 'School Dashboards',
    description: 'Intuitive teacher tools to track longitudinal progress over 3–5 years. NEP 2020-aligned Holistic Progress Cards auto-generated for every student.',
    accent: 'cyan',
  },
  {
    icon: BadgeCheck,
    title: 'Verified Athlete Profiles',
    description: 'A "LinkedIn for Sports" — verified digital passports for students aged 6–16. Data-backed pathways to scholarships and national leaderboards.',
    accent: 'emerald',
  },
  {
    icon: Telescope,
    title: 'Talent Watch Scouting',
    description: 'Academies and federations filter the national talent pool by biological fingerprints. Scouting-as-a-Service that eliminates fragmented recruitment.',
    accent: 'teal',
  },
];

const accentMap: Record<string, { bg: string; text: string; ring: string }> = {
  sky: { bg: 'bg-sky-50', text: 'text-sky-600', ring: 'ring-sky-100' },
  cyan: { bg: 'bg-cyan-50', text: 'text-cyan-600', ring: 'ring-cyan-100' },
  emerald: { bg: 'bg-emerald-50', text: 'text-emerald-600', ring: 'ring-emerald-100' },
  teal: { bg: 'bg-teal-50', text: 'text-teal-600', ring: 'ring-teal-100' },
};

export default function Solution() {
  const { ref, inView } = useInView();

  return (
    <section id="solution" className="py-28 bg-slate-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div
          ref={ref}
          className={`text-center mb-16 fade-up ${inView ? 'visible' : ''}`}
        >
          <div className="inline-flex items-center gap-2 bg-sky-50 border border-sky-100 rounded-full px-4 py-1.5 mb-6">
            <Brain className="w-3.5 h-3.5 text-sky-500" />
            <span className="text-sky-600 text-sm font-semibold">Scientific Measurement at Scale</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 tracking-tight mb-5">
            One Platform.<br />The Entire Talent Ecosystem.
          </h2>
          <p className="text-lg text-slate-500 max-w-2xl mx-auto leading-relaxed">
            Athlosys replaces fragmented observation with rigorous, kinesiology-based metrics —
            creating a seamless highway from school playground to professional scouting.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {solutions.map((item, i) => {
            const Icon = item.icon;
            const colors = accentMap[item.accent];
            return (
              <div
                key={item.title}
                className={`fade-up stagger-${i + 1} ${inView ? 'visible' : ''} card-hover bg-white border border-slate-100 rounded-2xl p-8 group`}
              >
                <div className={`${colors.bg} ring-1 ${colors.ring} w-12 h-12 rounded-xl flex items-center justify-center mb-5`}>
                  <Icon className={`w-6 h-6 ${colors.text}`} />
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">{item.title}</h3>
                <p className="text-slate-500 leading-relaxed">{item.description}</p>
              </div>
            );
          })}
        </div>

        <div className={`fade-up stagger-5 ${inView ? 'visible' : ''} bg-gradient-to-r from-sky-500 to-cyan-500 rounded-2xl p-8 md:p-10 text-white text-center`}>
          <blockquote className="text-xl md:text-2xl font-medium leading-relaxed max-w-3xl mx-auto">
            "Our objective is to facilitate a paradigm shift from subjective, gut-feeling scouting
            to quantified, scientific measurement."
          </blockquote>
          <p className="mt-4 text-sky-100 text-sm font-medium">— Athlosys Detailed Project Report</p>
        </div>
      </div>
    </section>
  );
}
