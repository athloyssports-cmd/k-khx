import { Smartphone, Cpu, Award, BarChart3, Link2 } from 'lucide-react';
import { useInView } from '../hooks/useInView';

const steps = [
  {
    number: '01',
    icon: Smartphone,
    title: 'Data Collection',
    description: 'PE teachers record anthropometric and motor skill data — running, jumping, agility — in minutes using the intuitive mobile app.',
    detail: 'No specialist required. Works in any environment.',
  },
  {
    number: '02',
    icon: Cpu,
    title: 'AI Analysis',
    description: 'Raw data is normalized for age and gender using Kinesiology and Eurofit frameworks, then processed through our MLP models.',
    detail: 'R-squared value: 0.665',
  },
  {
    number: '03',
    icon: Award,
    title: 'PPS & APR Scoring',
    description: 'Proprietary algorithms generate two metrics: Physical Profile Score for wellness and Athlete Potential Rating for elite forecasting.',
    detail: '72.73% predictive accuracy',
  },
  {
    number: '04',
    icon: BarChart3,
    title: 'Dynamic Leaderboards',
    description: 'Rankings synthesized at school, district, and national levels. Gamified fitness tracking that drives student engagement.',
    detail: 'School → District → National',
  },
  {
    number: '05',
    icon: Link2,
    title: 'Connection & Placement',
    description: 'Identified athletes are automatically matched to suitable sports and connected to scouts, academies, and scholarship opportunities.',
    detail: 'The talent highway completes.',
  },
];

export default function HowItWorks() {
  const { ref, inView } = useInView();

  return (
    <section id="how-it-works" className="py-28 bg-slate-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div
          ref={ref}
          className={`text-center mb-16 fade-up ${inView ? 'visible' : ''}`}
        >
          <div className="inline-flex items-center gap-2 bg-emerald-50 border border-emerald-100 rounded-full px-4 py-1.5 mb-6">
            <span className="text-emerald-600 text-sm font-semibold">The Five-Stage Talent Highway</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 tracking-tight mb-5">
            How It Works
          </h2>
          <p className="text-lg text-slate-500 max-w-xl mx-auto leading-relaxed">
            Operational simplicity. 20-minute sessions, twice a month.
            Fits within existing school schedules without disruption.
          </p>
        </div>

        <div className="relative">
          <div className="hidden lg:block absolute left-1/2 top-8 bottom-8 w-px bg-gradient-to-b from-sky-200 via-emerald-200 to-transparent -translate-x-1/2" />

          <div className="space-y-6">
            {steps.map((step, i) => {
              const Icon = step.icon;
              const isEven = i % 2 === 1;
              return (
                <div
                  key={step.number}
                  className={`fade-up stagger-${Math.min(i + 1, 5)} ${inView ? 'visible' : ''} flex flex-col lg:flex-row items-center gap-6 lg:gap-12 ${isEven ? 'lg:flex-row-reverse' : ''}`}
                >
                  <div className={`flex-1 ${isEven ? 'lg:text-right' : ''}`}>
                    <div className={`card-hover bg-white border border-slate-100 rounded-2xl p-7 ${isEven ? 'lg:ml-auto' : ''}`}>
                      <div className="flex items-start gap-4">
                        <div className="bg-sky-50 border border-sky-100 w-10 h-10 rounded-xl flex items-center justify-center shrink-0">
                          <Icon className="w-5 h-5 text-sky-600" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-slate-900 mb-2">{step.title}</h3>
                          <p className="text-slate-500 text-sm leading-relaxed mb-3">{step.description}</p>
                          <span className="inline-block bg-slate-100 text-slate-600 text-xs font-medium px-3 py-1 rounded-full">
                            {step.detail}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="relative z-10 flex-shrink-0 w-14 h-14 bg-white border-2 border-sky-200 rounded-full flex items-center justify-center shadow-sm">
                    <span className="text-sky-600 font-bold text-sm">{step.number}</span>
                  </div>

                  <div className="flex-1 hidden lg:block" />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
